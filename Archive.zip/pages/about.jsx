import Page from '../components/common/Page';

export default () => (
  <Page>
    <div className="container">
      THIS IS ABOUT PAGE
    </div>
  </Page>
);
